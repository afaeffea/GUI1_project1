﻿using System;
using System.Windows.Forms;
using System.Drawing;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

            this.KeyPreview = true; // Разрешаем предварительный просмотр клавиш на форме
            this.KeyDown += Form1_KeyDown; // Привязываем обработчик события KeyDown к форме

            // Загрузка сохраненных значений из настроек
            textBox1.Text = Properties.Settings.Default.a.ToString();
            textBox2.Text = Properties.Settings.Default.b.ToString();
            textBox3.Text = Properties.Settings.Default.c.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Считываем значения из текстовых полей и преобразуем в числа
                if (double.TryParse(textBox1.Text, out double a) &&
                    double.TryParse(textBox2.Text, out double b) &&
                    double.TryParse(textBox3.Text, out double c))
                {
                    // Вызываем метод для проверки существования треугольника
                    string outMessage = Logic.ExistTriangle(a, b, c);

                    // Отображаем результат
                    MessageBox.Show(outMessage, "Результат");

                    // Сохранение новых значений в настройках
                    Properties.Settings.Default.a = a;
                    Properties.Settings.Default.b = b;
                    Properties.Settings.Default.c = c;
                    Properties.Settings.Default.Save(); // Сохранение изменений
                }
                else
                {
                    MessageBox.Show("Пожалуйста, введите корректные числовые значения во все поля.", "Ошибка ввода");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка");
            }
        }
        private void ClearFields()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }
        private void button2_Click(object sender, EventArgs e)
        {
             ClearFields(); // Вызываем метод очистки полей
        }
        private void txtA_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true; // Предотвращаем "двойное" срабатывание Enter

                // Перемещаем фокус на следующий элемент интерфейса
                SelectNextControl((Control)sender, true, true, true, true);
            }
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true; // Предотвращаем обработку клавиши Enter другими элементами управления

                // Код для перехода к следующему элементу интерфейса
                this.SelectNextControl(this.ActiveControl, true, true, true, true);
            }
        }
    }

    public class Logic
    {
        public static string ExistTriangle(double a, double b, double c)
        {
            string outMessage = "";
            if (a <= 0 && b > 0 && c > 0)
                outMessage = "Первое значение не подходит";
            else if (a > 0 && b <= 0 && c > 0)
                outMessage = "Второе значение не подходит";
            else if (a > 0 && b > 0 && c <= 0)
                outMessage = "Третье значение не подходит";
            else if (a <= 0 && b <= 0 && c <= 0)
                outMessage = "Все значения не подходят";
            else if (a <= 0 && b <= 0 && c > 0)
                outMessage = "Первое и второе значения не подходят";
            else if (a <= 0 && b > 0 && c <= 0)
                outMessage = "Первое и третье значения не подходят";
            else if (a > 0 && b <= 0 && c <= 0)
                outMessage = "Второе и третье значения не подходят";
            else
            {
                if (a + b <= c || a + c <= b || b + c <= a)
                    outMessage = "Не существует треугольника с такими параметрами";
                else if (a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a)
                    outMessage = "Треугольник является прямоугольным";
                else
                    outMessage = "Треугольник не является прямоугольным";
            }
            return outMessage;
        }

    }
}
